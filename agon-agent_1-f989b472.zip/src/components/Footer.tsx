import { Mail, Phone, MapPin } from 'lucide-react';
import Logo from './Logo';

const socials = ['Instagram', 'LinkedIn', 'X', 'YouTube'];
const nav = [
  { h: 'Company', items: ['About', 'Process', 'Results', 'Careers'] },
  { h: 'Services', items: ['Meta Ads', 'Landing Pages', 'Lead Funnels', 'CRM Automation'] },
  { h: 'Industries', items: ['Real Estate', 'Dentists', 'Coaches', 'Local Business'] },
];

export default function Footer() {
  return (
    <footer className="relative bg-panel px-5 pt-16 pb-8">
      <div className="mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <Logo className="text-3xl text-white" dot="#f26b1e" />
            <p className="mt-4 max-w-xs text-sm text-white/55 leading-relaxed">
              We help businesses generate qualified leads through high-converting Meta Ads, landing pages, and conversion systems.
            </p>
            <div className="mt-6 space-y-2 text-sm text-white/55">
              <a href="mailto:hello@bikri.agency" className="flex items-center gap-2 hover:text-orange transition-colors"><Mail className="w-4 h-4 text-orange" />hello@bikri.agency</a>
              <a href="tel:+10000000000" className="flex items-center gap-2 hover:text-orange transition-colors"><Phone className="w-4 h-4 text-orange" />+1 (000) 000-0000</a>
              <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-orange" />Remote — Worldwide</span>
            </div>
          </div>

          {nav.map((col) => (
            <div key={col.h} className="lg:col-span-2">
              <h4 className="text-sm font-semibold text-white mb-4">{col.h}</h4>
              <ul className="space-y-2.5">
                {col.items.map((it) => (
                  <li key={it}><a href="#" className="text-sm text-white/55 hover:text-orange transition-colors">{it}</a></li>
                ))}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-2">
            <h4 className="text-sm font-semibold text-white mb-4">Social</h4>
            <ul className="space-y-2.5">
              {socials.map((s) => (
                <li key={s}><a href="#" className="text-sm text-white/55 hover:text-orange transition-colors">{s}</a></li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 pt-7 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/55">© {new Date().getFullYear()} बिक्री. All rights reserved.</p>
          <div className="flex items-center gap-6 text-xs text-white/55">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />Accepting clients</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
