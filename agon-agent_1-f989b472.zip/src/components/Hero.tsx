import { motion } from 'framer-motion';
import { ArrowRight, Play, Sparkles } from 'lucide-react';
import Logo from './Logo';
import BookButton from './BookButton';

const ease = [0.22, 1, 0.36, 1] as const;

function Word({ children, delay }: { children: string; delay: number }) {
  return (
    <span className="inline-block overflow-hidden align-bottom">
      <motion.span
        className="inline-block"
        initial={{ y: '110%' }}
        animate={{ y: 0 }}
        transition={{ duration: 0.85, ease, delay }}
      >
        {children}
      </motion.span>
    </span>
  );
}

export default function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex flex-col items-center justify-center px-5 pt-28 pb-16 overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
      <div className="orb absolute -top-40 left-1/2 -translate-x-1/2 w-[120vw] sm:w-[850px] h-[850px] rounded-full bg-[radial-gradient(circle,rgba(255,138,61,0.55),transparent_62%)] blur-[60px]" />
      <div className="orb2 absolute top-1/3 -right-40 w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle,rgba(212,84,15,0.4),transparent_65%)] blur-[80px]" />
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-bg to-transparent" />

      <div className="relative z-10 w-full max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease }}
          className="flex justify-center mb-8"
        >
          <Logo className="text-7xl sm:text-8xl md:text-9xl text-ink drop-shadow-[0_8px_30px_rgba(0,0,0,0.25)]" dot="#0a0a0a" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="inline-flex items-center gap-2 rounded-full border border-ink/20 bg-ink/[0.06] px-4 py-1.5 text-xs font-semibold text-ink mb-7"
        >
          <Sparkles className="w-3.5 h-3.5" />
          Lead Generation, Engineered for Conversion
        </motion.div>

        <h1 className="text-balance font-bold tracking-tight text-[2.6rem] leading-[1.02] sm:text-6xl md:text-7xl text-ink">
          <span className="block">
            <Word delay={0.35}>Turn</Word>{' '}
            <Word delay={0.42}>Attention</Word>{' '}
            <Word delay={0.49}>Into</Word>
          </span>
          <span className="block mt-1 text-ink/55">
            <Word delay={0.58}>Qualified</Word>{' '}
            <Word delay={0.65}>Leads.</Word>
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.85 }}
          className="mx-auto mt-6 max-w-xl text-base sm:text-lg text-ink-light text-balance"
        >
          We build lead generation systems that consistently attract, qualify, and convert prospects into customers.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 1 }}
          className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-3"
        >
          <BookButton className="group shadow-ink w-full sm:w-auto cursor-pointer inline-flex items-center justify-center gap-2 rounded-full bg-ink px-7 h-14 text-base font-semibold text-bg transition-all hover:scale-[1.03] active:scale-95">
            Book Free Strategy Call
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          </BookButton>
          <a
            href="#services"
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-full border border-ink/25 bg-ink/[0.04] backdrop-blur px-7 h-14 text-base font-semibold text-ink transition-all hover:bg-ink/[0.09] hover:border-ink/40"
          >
            <Play className="w-4 h-4 fill-current" />
            See How It Works
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.3 }}
          className="mt-10 flex items-center justify-center gap-2 text-xs text-ink-light font-medium"
        >
          <span className="flex -space-x-1.5">
            {[0,1,2,3].map((i) => (
              <span key={i} className="w-6 h-6 rounded-full border-2 border-bg bg-ink" style={{ opacity: 1 - i * 0.16 }} />
            ))}
          </span>
          Trusted by real estate, dental, design &amp; coaching brands
        </motion.div>
      </div>
    </section>
  );
}
