const niches = [
  'Real Estate', 'Dentists', 'Interior Designers', 'Coaches',
  'Service Businesses', 'High-Ticket Local', 'Med Spas', 'Law Firms',
];

export default function Marquee() {
  return (
    <section className="relative bg-ink py-6 overflow-hidden">
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink to-transparent z-10" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink to-transparent z-10" />
      <div className="flex w-max marquee-track">
        {[0, 1].map((dup) => (
          <div key={dup} className="flex items-center" aria-hidden={dup === 1}>
            {niches.map((n) => (
              <div key={n + dup} className="flex items-center gap-3 px-8">
                <span className="w-1.5 h-1.5 rounded-full bg-orange" />
                <span className="text-lg sm:text-xl font-semibold text-white/55 whitespace-nowrap">{n}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}
