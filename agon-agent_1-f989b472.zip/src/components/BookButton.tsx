import { forwardRef, useEffect, type ReactNode, type MouseEvent } from 'react';
import { getCalApi } from '@calcom/embed-react';
import { BOOKING, bookingHref } from '../lib/booking';

// Initialize Cal.com embed once (dark theme + brand color)
let calInitialized = false;

export function useCalInit() {
  useEffect(() => {
    if (BOOKING.provider !== 'cal' || calInitialized) return;
    calInitialized = true;
    (async () => {
      const cal = await getCalApi();
      cal('ui', {
        theme: 'dark',
        cssVarsPerTheme: {
          light: { 'cal-brand': '#ff6a00' },
          dark: { 'cal-brand': '#ff6a00' },
        },
        hideEventTypeDetails: false,
        layout: 'month_view',
      });
    })();
  }, []);
}

// Load Calendly popup script lazily when needed
function openCalendly(url: string) {
  const w = window as unknown as { Calendly?: { initPopupWidget: (o: { url: string }) => void } };
  const launch = () => w.Calendly?.initPopupWidget({ url });

  if (w.Calendly) {
    launch();
    return;
  }
  if (!document.getElementById('calendly-css')) {
    const link = document.createElement('link');
    link.id = 'calendly-css';
    link.rel = 'stylesheet';
    link.href = 'https://assets.calendly.com/assets/external/widget.css';
    document.head.appendChild(link);
  }
  const existing = document.getElementById('calendly-js') as HTMLScriptElement | null;
  if (existing) {
    existing.addEventListener('load', launch);
    return;
  }
  const s = document.createElement('script');
  s.id = 'calendly-js';
  s.src = 'https://assets.calendly.com/assets/external/widget.js';
  s.async = true;
  s.onload = launch;
  document.body.appendChild(s);
}

type Props = {
  children: ReactNode;
  className?: string;
};

const BookButton = forwardRef<HTMLAnchorElement, Props>(function BookButton(
  { children, className },
  ref,
) {
  const href = bookingHref();

  if (BOOKING.provider === 'cal') {
    return (
      <a
        ref={ref}
        href={href}
        data-cal-link={BOOKING.calLink}
        data-cal-config='{"layout":"month_view","theme":"dark"}'
        onClick={(e) => {
          // Cal embed intercepts clicks; if it didn't load, the href still works.
          if (!(window as unknown as { Cal?: unknown }).Cal) return;
          e.preventDefault();
        }}
        className={className}
      >
        {children}
      </a>
    );
  }

  if (BOOKING.provider === 'calendly') {
    return (
      <a
        ref={ref}
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e: MouseEvent) => {
          e.preventDefault();
          openCalendly(href);
        }}
        className={className}
      >
        {children}
      </a>
    );
  }

  return (
    <a ref={ref} href={href} target="_blank" rel="noopener noreferrer" className={className}>
      {children}
    </a>
  );
});

export default BookButton;
