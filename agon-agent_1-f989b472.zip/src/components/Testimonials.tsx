import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';
import Reveal from './Reveal';

const testimonials = [
  {
    quote: 'In our first 60 days we booked more qualified appointments than the previous year combined. The system just works.',
    name: 'Priya Nair',
    role: 'Founder, Aether Interiors',
    initials: 'PN',
  },
  {
    quote: 'Cost per lead dropped 61% while volume tripled. Their reporting is the most transparent I have ever seen from an agency.',
    name: 'Marcus Reed',
    role: 'Principal, Reed Realty Group',
    initials: 'MR',
  },
  {
    quote: 'We went from chasing referrals to a predictable calendar of high-intent patients. बिक्री changed our business.',
    name: 'Dr. Anya Kapoor',
    role: 'Owner, Brightsmile Dental',
    initials: 'AK',
  },
  {
    quote: 'The funnel they built converts cold traffic into discovery calls at a rate I did not think was possible for coaching.',
    name: 'Daniel Osei',
    role: 'Executive Coach',
    initials: 'DO',
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32 px-5">
      <div className="mx-auto max-w-6xl">
        <Reveal className="max-w-2xl mb-14">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-ink/60 mb-4">/ Proof</p>
          <h2 className="text-balance text-4xl sm:text-5xl font-bold tracking-tight text-ink">
            Operators who scaled with us.
          </h2>
        </Reveal>

        <div className="grid md:grid-cols-2 gap-4">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.08}>
              <motion.figure
                whileHover={{ y: -4 }}
                className="relative h-full rounded-3xl bg-cream shadow-ink p-8"
              >
                <Quote className="w-8 h-8 text-orange mb-4" />
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} className="w-4 h-4 fill-orange text-orange" />
                  ))}
                </div>
                <blockquote className="text-lg text-ink leading-relaxed text-balance">“{t.quote}”</blockquote>
                <figcaption className="mt-7 flex items-center gap-3">
                  <span className="flex items-center justify-center w-11 h-11 rounded-full bg-ink text-bg font-bold text-sm">
                    {t.initials}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-ink">{t.name}</span>
                    <span className="block text-xs text-ink/55">{t.role}</span>
                  </span>
                </figcaption>
              </motion.figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
