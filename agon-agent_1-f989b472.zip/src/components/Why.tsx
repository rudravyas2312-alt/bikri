import { motion } from 'framer-motion';
import { BarChart3, Crosshair, Zap, Eye, Layers } from 'lucide-react';
import Reveal from './Reveal';

const reasons = [
  { icon: BarChart3, title: 'Data Driven', desc: 'Every decision backed by real performance data, not guesswork.' },
  { icon: Crosshair, title: 'Conversion Focused', desc: 'We optimize for booked calls and revenue — not vanity metrics.' },
  { icon: Zap, title: 'Fast Execution', desc: 'Campaigns live in 7 days, with iteration cycles measured in hours.' },
  { icon: Eye, title: 'Transparent Reporting', desc: 'A live dashboard you can check anytime. No black boxes.' },
  { icon: Layers, title: 'Scalable Systems', desc: 'Built to compound — spend more, get more, profitably.' },
];

export default function Why() {
  return (
    <section id="why" className="relative py-24 sm:py-32 px-5 scroll-mt-20">
      <div className="mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
          <Reveal className="lg:col-span-4">
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-ink/60 mb-4">/ Why बिक्री</p>
            <h2 className="text-balance text-4xl sm:text-5xl font-bold tracking-tight text-ink">
              Built different. Built to convert.
            </h2>
            <p className="mt-5 text-ink-light leading-relaxed">
              We don’t just run ads. We engineer the entire system that turns ad spend into predictable, qualified pipeline.
            </p>
          </Reveal>

          <div className="lg:col-span-8 grid sm:grid-cols-2 gap-4">
            {reasons.map((r, i) => (
              <Reveal key={r.title} delay={i * 0.07} className={i === 0 ? 'sm:col-span-2' : ''}>
                <motion.div
                  whileHover={{ x: 4 }}
                  className="group flex gap-4 items-start rounded-2xl bg-panel shadow-ink p-6 transition-colors"
                >
                  <div className="shrink-0 flex items-center justify-center w-11 h-11 rounded-xl bg-orange/15 border border-orange/30 text-orange group-hover:scale-110 transition-transform">
                    <r.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{r.title}</h3>
                    <p className="mt-1 text-sm text-white/65 leading-relaxed">{r.desc}</p>
                  </div>
                </motion.div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
