import { motion } from 'framer-motion';
import { Target, LayoutTemplate, Filter, Workflow, ArrowUpRight } from 'lucide-react';
import Reveal from './Reveal';

const services = [
  {
    icon: Target,
    title: 'Meta Ads',
    desc: 'Generate targeted, qualified leads at scale with precision audience targeting and relentless creative testing.',
    span: 'lg:col-span-3',
  },
  {
    icon: LayoutTemplate,
    title: 'Landing Pages',
    desc: 'Conversion-optimized pages designed to turn clicks into customers.',
    span: 'lg:col-span-3',
  },
  {
    icon: Filter,
    title: 'Lead Funnels',
    desc: 'Complete customer acquisition systems built end-to-end.',
    span: 'lg:col-span-2',
  },
  {
    icon: Workflow,
    title: 'CRM Automation',
    desc: 'Lead tracking and automated follow-up that never lets a prospect slip through.',
    span: 'lg:col-span-4',
  },
];

export default function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32 px-5 scroll-mt-20">
      <div className="mx-auto max-w-6xl">
        <Reveal className="max-w-2xl mb-14">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-ink/60 mb-4">/ What we do</p>
          <h2 className="text-balance text-4xl sm:text-5xl font-bold tracking-tight text-ink">
            A full-stack growth engine, not just ads.
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-6 gap-4">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.08} className={s.span}>
              <motion.div
                whileHover={{ y: -6 }}
                transition={{ type: 'spring', stiffness: 300, damping: 22 }}
                className="card-glow group relative h-full overflow-hidden rounded-3xl bg-panel shadow-ink p-8 transition-colors"
              >
                <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-orange/25 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative flex items-start justify-between">
                  <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-orange/15 border border-orange/30 text-orange transition-transform group-hover:scale-110 group-hover:rotate-3">
                    <s.icon className="w-6 h-6" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-white/40 transition-all group-hover:text-orange group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <h3 className="relative mt-6 text-2xl font-semibold text-white">{s.title}</h3>
                <p className="relative mt-2 text-white/65 leading-relaxed max-w-md">{s.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
