import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import Logo from './Logo';
import BookButton from './BookButton';

const links = [
  { label: 'Services', href: '#services' },
  { label: 'Process', href: '#process' },
  { label: 'Results', href: '#results' },
  { label: 'Why Us', href: '#why' },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 inset-x-0 z-50 px-4 sm:px-6"
    >
      <div
        className={`mx-auto max-w-6xl mt-3 sm:mt-4 flex items-center justify-between rounded-full px-4 sm:px-6 h-14 transition-all duration-500 ${
          scrolled
            ? 'bg-bg/80 backdrop-blur-xl border border-ink/15 shadow-[0_10px_40px_-16px_rgba(0,0,0,0.45)]'
            : 'bg-transparent border border-transparent'
        }`}
      >
        <a href="#top" className="flex items-center">
          <Logo className="text-2xl text-ink" dot="#0a0a0a" />
        </a>
        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="px-4 py-2 text-sm font-medium text-ink-light hover:text-ink transition-colors rounded-full hover:bg-ink/[0.06]"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <BookButton className="group relative inline-flex cursor-pointer items-center gap-2 rounded-full bg-ink px-4 sm:px-5 h-10 text-sm font-semibold text-bg transition-transform hover:scale-[1.03] active:scale-95">
          Book a Call
          <span className="hidden sm:inline transition-transform group-hover:translate-x-0.5">→</span>
        </BookButton>
      </div>
    </motion.header>
  );
}
