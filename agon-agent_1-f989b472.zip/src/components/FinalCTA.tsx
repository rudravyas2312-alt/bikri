import { motion } from 'framer-motion';
import { ArrowRight, Check } from 'lucide-react';
import Reveal from './Reveal';
import BookButton from './BookButton';

const MotionBook = motion.create(BookButton);

const perks = ['No commitment', 'Custom growth audit', '30-minute call'];

export default function FinalCTA() {
  return (
    <section id="book" className="relative py-24 sm:py-36 px-5 scroll-mt-20">
      <div className="mx-auto max-w-5xl">
        <Reveal>
          <div className="relative overflow-hidden rounded-[36px] bg-panel px-6 sm:px-12 py-16 sm:py-20 text-center shadow-[0_50px_120px_-40px_rgba(0,0,0,0.65)]">
            <div className="orb absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-[radial-gradient(circle,rgba(242,107,30,0.5),transparent_60%)] blur-[60px]" />
            <div className="absolute inset-0 grid-bg-dark [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
            <div className="relative">
              <h2 className="text-balance text-4xl sm:text-6xl font-bold tracking-tight text-white">
                Ready To Scale Your Lead Generation?
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-base sm:text-lg text-white/70 text-balance">
                Book a free strategy session and discover your next growth opportunity.
              </p>
              <MotionBook
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                className="mt-9 cursor-pointer inline-flex items-center gap-2 rounded-full bg-orange px-9 h-15 py-4 text-lg font-semibold text-ink shadow-[0_18px_50px_-12px_rgba(242,107,30,0.6)]"
              >
                Book Free Call
                <ArrowRight className="w-5 h-5" />
              </MotionBook>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
                {perks.map((p) => (
                  <span key={p} className="flex items-center gap-2 text-sm text-white/75">
                    <Check className="w-4 h-4 text-orange" />{p}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
