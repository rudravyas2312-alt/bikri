import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import Reveal from './Reveal';

function Counter({ to, suffix = '', prefix = '', decimals = 0 }: { to: number; suffix?: string; prefix?: string; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const dur = 1600;
    const tick = (now: number) => {
      const p = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(to * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref}>
      {prefix}{val.toLocaleString(undefined, { maximumFractionDigits: decimals, minimumFractionDigits: decimals })}{suffix}
    </span>
  );
}

const stats = [
  { label: 'Qualified Leads Generated', node: <Counter to={48000} suffix="+" /> },
  { label: 'Conversion-Focused Systems', node: <Counter to={120} suffix="+" /> },
  { label: 'Average Return On Ad Spend', node: <Counter to={6.4} suffix="x" decimals={1} /> },
  { label: 'Days To Launch', node: <Counter to={7} /> },
];

export default function Stats() {
  return (
    <section className="relative py-20 sm:py-28 px-5">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px rounded-3xl overflow-hidden bg-white/10 shadow-ink ring-1 ring-ink/10">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08}>
              <motion.div
                whileHover={{ backgroundColor: 'rgba(242,107,30,0.12)' }}
                className="h-full bg-panel p-7 sm:p-9 flex flex-col gap-3"
              >
                <div className="text-4xl sm:text-5xl font-bold tracking-tight text-orange">
                  {s.node}
                </div>
                <div className="text-xs sm:text-sm text-white/70 font-medium leading-snug">{s.label}</div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
