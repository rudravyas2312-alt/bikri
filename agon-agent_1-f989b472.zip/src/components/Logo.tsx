export default function Logo({ className = '', dot = '#f26b1e' }: { className?: string; dot?: string }) {
  return (
    <span className={`font-deva font-extrabold tracking-tight leading-none ${className}`}>
      बिक्री<span style={{ color: dot }}>.</span>
    </span>
  );
}
