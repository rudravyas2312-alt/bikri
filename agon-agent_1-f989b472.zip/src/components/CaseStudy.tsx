import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { TrendingUp, Users, DollarSign, MousePointerClick, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import Reveal from './Reveal';

const bars = [32, 40, 38, 52, 61, 58, 74, 82, 79, 95, 100, 92];
const months = ['J','F','M','A','M','J','J','A','S','O','N','D'];

function MiniCounter({ to, prefix = '', suffix = '', decimals = 0 }: { to: number; prefix?: string; suffix?: string; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0; const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / 1400, 1);
      setV(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return <span ref={ref}>{prefix}{v.toLocaleString(undefined, { maximumFractionDigits: decimals, minimumFractionDigits: decimals })}{suffix}</span>;
}

const kpis = [
  { icon: Users, label: 'Leads / mo', node: <MiniCounter to={1284} />, delta: '+212%', up: true },
  { icon: DollarSign, label: 'Cost / Lead', node: <MiniCounter to={4.8} prefix="$" decimals={1} />, delta: '-63%', up: false },
  { icon: MousePointerClick, label: 'Conv. Rate', node: <MiniCounter to={11.6} suffix="%" decimals={1} />, delta: '+88%', up: true },
  { icon: TrendingUp, label: 'ROAS', node: <MiniCounter to={7.2} suffix="x" decimals={1} />, delta: '+140%', up: true },
];

export default function CaseStudy() {
  return (
    <section id="results" className="relative py-24 sm:py-32 px-5 scroll-mt-20">
      <div className="mx-auto max-w-6xl">
        <Reveal className="max-w-2xl mb-12">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-ink/60 mb-4">/ Real results</p>
          <h2 className="text-balance text-4xl sm:text-5xl font-bold tracking-tight text-ink">
            The dashboard our clients wake up to.
          </h2>
          <p className="mt-4 text-ink-light">A snapshot from a high-ticket local services client — 90 days after launch.</p>
        </Reveal>

        <Reveal>
          <div className="relative rounded-[28px] bg-panel p-3 sm:p-4 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.6)] ring-1 ring-ink/10">
            {/* window chrome */}
            <div className="flex items-center gap-2 px-3 py-2.5">
              <span className="w-3 h-3 rounded-full bg-white/15" />
              <span className="w-3 h-3 rounded-full bg-white/15" />
              <span className="w-3 h-3 rounded-full bg-orange" />
              <span className="ml-3 font-mono text-xs text-white/50">bikri — lead intelligence</span>
              <span className="ml-auto hidden sm:flex items-center gap-1.5 text-xs text-emerald-400"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />Live</span>
            </div>

            <div className="rounded-2xl bg-black/50 border border-white/10 p-4 sm:p-6">
              {/* KPI row */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
                {kpis.map((k) => (
                  <div key={k.label} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                    <div className="flex items-center justify-between">
                      <k.icon className="w-4 h-4 text-white/40" />
                      <span className="flex items-center gap-0.5 text-[11px] font-semibold text-emerald-400">
                        {k.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}{k.delta}
                      </span>
                    </div>
                    <div className="mt-3 text-2xl font-bold text-white">{k.node}</div>
                    <div className="text-[11px] text-white/45 mt-0.5">{k.label}</div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Bar chart */}
                <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <div className="flex items-center justify-between mb-5">
                    <div>
                      <div className="text-sm font-semibold text-white">Qualified Leads</div>
                      <div className="text-xs text-white/45">Trailing 12 months</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-orange"><MiniCounter to={9842} suffix="" /></div>
                      <div className="text-[11px] text-white/45">total</div>
                    </div>
                  </div>
                  <div className="flex items-end justify-between gap-1.5 h-40">
                    {bars.map((b, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          whileInView={{ height: `${b}%`, opacity: 1 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                          className={`w-full rounded-md ${i >= bars.length - 3 ? 'bg-gradient-to-t from-orange to-orange-soft' : 'bg-white/15'}`}
                        />
                        <span className="text-[10px] text-white/45 font-mono">{months[i]}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Donut / funnel */}
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 flex flex-col">
                  <div className="text-sm font-semibold text-white mb-1">Funnel Quality</div>
                  <div className="text-xs text-white/45 mb-5">Lead → booked</div>
                  <div className="relative mx-auto my-2 w-32 h-32">
                    <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="4" />
                      <motion.circle
                        cx="18" cy="18" r="15.5" fill="none" stroke="#f26b1e" strokeWidth="4" strokeLinecap="round"
                        strokeDasharray="97.4"
                        initial={{ strokeDashoffset: 97.4 }}
                        whileInView={{ strokeDashoffset: 97.4 * (1 - 0.68) }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-2xl font-bold text-white"><MiniCounter to={68} suffix="%" /></div>
                      <div className="text-[10px] text-white/45">show rate</div>
                    </div>
                  </div>
                  <div className="mt-auto space-y-2 pt-4">
                    {[['Qualified', '82%'], ['Booked', '68%'], ['Closed', '41%']].map(([l, v]) => (
                      <div key={l} className="flex items-center justify-between text-xs">
                        <span className="text-white/55">{l}</span>
                        <span className="text-white font-medium">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
