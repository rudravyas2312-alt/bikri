import { motion } from 'framer-motion';
import Reveal from './Reveal';

const steps = [
  { n: '01', title: 'Research & Strategy', desc: 'We map your offer, audience, and economics to design a conversion path built for your numbers.' },
  { n: '02', title: 'Campaign Creation', desc: 'High-intent creative, copy, and funnels engineered to stop the scroll and qualify the click.' },
  { n: '03', title: 'Lead Generation', desc: 'We launch, drive qualified traffic, and route leads straight into your pipeline in real time.' },
  { n: '04', title: 'Optimization & Scaling', desc: 'Daily data review, creative iteration, and budget scaling to compound your cost-per-lead down.' },
];

export default function Process() {
  return (
    <section id="process" className="relative py-24 sm:py-32 px-5 scroll-mt-20">
      <div className="absolute inset-0 grid-bg [mask-image:linear-gradient(to_bottom,transparent,black_20%,black_80%,transparent)] opacity-50" />
      <div className="relative mx-auto max-w-6xl">
        <Reveal className="max-w-2xl mb-16">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-ink/60 mb-4">/ How it works</p>
          <h2 className="text-balance text-4xl sm:text-5xl font-bold tracking-tight text-ink">
            A proven system in four moves.
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -6 }}
                className="group relative h-full rounded-3xl bg-panel shadow-ink p-7 overflow-hidden"
              >
                <div className="absolute top-0 left-0 h-1 w-0 bg-orange transition-all duration-500 group-hover:w-full" />
                <div className="font-mono text-5xl font-bold text-white/15 group-hover:text-orange transition-colors">{s.n}</div>
                <h3 className="mt-5 text-xl font-semibold text-white">{s.title}</h3>
                <p className="mt-2 text-sm text-white/65 leading-relaxed">{s.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
