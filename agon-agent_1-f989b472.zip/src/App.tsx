import Nav from './components/Nav';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import Stats from './components/Stats';
import Services from './components/Services';
import Process from './components/Process';
import CaseStudy from './components/CaseStudy';
import Why from './components/Why';
import Testimonials from './components/Testimonials';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import { useCalInit } from './components/BookButton';

export default function App() {
  useCalInit();

  return (
    <div className="relative min-h-screen bg-bg text-ink antialiased">
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <Stats />
        <Services />
        <Process />
        <CaseStudy />
        <Why />
        <Testimonials />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
