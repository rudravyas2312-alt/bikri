// ─────────────────────────────────────────────────────────────
//  BOOKING CONFIG  —  edit this one file to point at your calendar
// ─────────────────────────────────────────────────────────────
//
//  CAL.COM  (recommended, free, opens a sleek modal)
//  --------------------------------------------------
//  1. Create an event type at https://cal.com  (e.g. "Strategy Call")
//  2. Your link looks like:  cal.com/your-name/strategy-call
//  3. Put just the slug part below, WITHOUT "https://cal.com/"
//
//     calLink = "your-name/strategy-call"
//
//  CALENDLY  (alternative)
//  --------------------------------------------------
//  Set provider to "calendly" and paste your full Calendly URL, e.g.
//     calendlyUrl = "https://calendly.com/your-name/strategy-call"
//
// ─────────────────────────────────────────────────────────────

export const BOOKING = {
  // "cal" -> opens Cal.com modal popup
  // "calendly" -> opens Calendly popup
  // "link" -> just opens the rawUrl in a new tab (use this for any other tool)
  provider: 'calendly' as 'cal' | 'calendly' | 'link',

  // Cal.com slug (no domain). Replace "bikri/strategy-call" with yours.
  calLink: 'bikri/strategy-call',

  // Calendly full URL (only used if provider === "calendly")
  calendlyUrl: 'https://calendly.com/rudravyas2312/30min',

  // Generic fallback / used when provider === "link"
  rawUrl: 'https://calendly.com/rudravyas2312/30min',
};

// Resolve a plain URL we can always fall back to (e.g. open in new tab)
export function bookingHref(): string {
  if (BOOKING.provider === 'calendly') return BOOKING.calendlyUrl;
  if (BOOKING.provider === 'cal') return `https://cal.com/${BOOKING.calLink}`;
  return BOOKING.rawUrl;
}
